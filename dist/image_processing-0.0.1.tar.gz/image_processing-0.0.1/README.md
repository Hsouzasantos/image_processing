<h1>Processador de Imagem</h1>
<h3>Desenvolvido como projeto de aprendizado de python</h3>

<h2>Installation</h2>
Deve usar o gerenciador de pacotes pip para instalar o image_processing

'''bash
pip install image_processing
'''

<h2>Usage</h2>
'''python
from image_processing import combination
combination.find_difference(image1, image2)
'''

<h2>License</h2>
MIT